package com.hcl.shopforhome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopforhomeApplicationTests {

	@Test
	void contextLoads() {
	}

}
