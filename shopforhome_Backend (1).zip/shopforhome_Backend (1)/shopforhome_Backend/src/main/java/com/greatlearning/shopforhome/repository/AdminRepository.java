package com.greatlearning.shopforhome.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.greatlearning.shopforhome.model.Admin;




public interface AdminRepository extends JpaRepository<Admin, String> {

}
